'''
DOCSTRING TO BE WRITTEN
'''

from COBY.main_class.__init__ import *
from COBY.version import __version__, version_changes, changes, changelog