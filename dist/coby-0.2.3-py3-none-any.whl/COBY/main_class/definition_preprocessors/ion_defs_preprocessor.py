from COBY.structure_classes.SOLVENT_class import SOLVENT
import copy

class ion_defs_preprocessor:
    def ion_defs_preprocessor(self):
        '''
        Preprocesses ion defintions by rearranging the data into a class
        '''
        self.print_term("Preprocessing ion definitions", verbose=2)
        ### Creates parameter libraries in the solvent defs for positive and negative ions
        ### In case people want to flood a system with a specific number of ions
        molecules_for_preprocessing = []
        if hasattr(self, "ion_defs") and self.ion_defs:
            molecules_for_preprocessing.append(("defs", self.ion_defs))

        if hasattr(self, "ion_defs_built") and self.ion_defs_built:
            molecules_for_preprocessing.append(("defs", self.ion_defs_built))

        if hasattr(self, "ion_defs_imported") and self.ion_defs_imported:
            molecules_for_preprocessing.append(("import", self.ion_defs_imported))

        for structure_origin, defs in molecules_for_preprocessing:
            for params, charge_type_dict in defs.items():
                pos_ions_params = "_".join(["pos_ions", params])
                neg_ions_params = "_".join(["neg_ions", params])
                if pos_ions_params not in self.solvent_defs.keys():
                    self.solvent_defs[pos_ions_params] = {}
                if neg_ions_params not in self.solvent_defs.keys():
                    self.solvent_defs[neg_ions_params] = {}

                if params not in self.ion_dict.keys():
                    self.ion_dict[params] = {}
                for charge_name, ion_type_dict in charge_type_dict.items():
                    if charge_name not in self.ion_dict[params].keys():
                        self.ion_dict[params][charge_name] = {}
                    ### Loop over indexes
                    for cur_name, cur_dict in ion_type_dict.items():
                        if cur_name not in self.ion_dict[params][charge_name].keys():
                            ion = SOLVENT(mapping_ratio = 1, molname = cur_name)
                            self.ion_dict[params][charge_name][cur_name] = ion
                            ### Adding ion libraries to solvent libraries
                            if charge_name not in self.solvent_defs[pos_ions_params].keys():
                                self.solvent_defs[pos_ions_params][cur_name] = copy.deepcopy(cur_dict)
                            if charge_name not in self.solvent_defs[neg_ions_params].keys():
                                self.solvent_defs[neg_ions_params][cur_name] = copy.deepcopy(cur_dict)
                        else:
                            if charge_name == "pos_ions":
                                ion_name = "positive"
                            if charge_name == "neg_ions":
                                ion_name = "negative"
                            self.print_term(
                                "The name \"{name}\" has been detected multiple times for {ion_name} ions within the same parameter library.".format(name=cur_name, ion_name=ion_name),
                                "If multiple {ion_name} ions have the same name then only the first is loaded into the library.".format(ion_name=ion_name),
                                warn=True,
                            )
                            continue
                        
                        self.molecule_defs_checker(self.ion_dict[params][charge_name][cur_name], cur_name, cur_dict, type_of_molecule = "solvent", structure_origin=structure_origin)

        tot_pos_ions = sum([len(vals["positive"]) for vals in self.ion_dict.values()])
        self.print_term("Number of positive ions preprocessed:", tot_pos_ions, spaces=1, verbose=2)
        tot_neg_ions = sum([len(vals["negative"]) for vals in self.ion_dict.values()])
        self.print_term("Number of negative ions preprocessed:", tot_neg_ions, "\n", spaces=1, verbose=2)
