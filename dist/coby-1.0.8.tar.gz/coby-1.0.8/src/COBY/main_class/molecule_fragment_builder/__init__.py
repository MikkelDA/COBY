'''
DOCSTRING TO BE WRITTEN
'''

from COBY.main_class.molecule_fragment_builder.molecule_fragment_builder import *

class molecule_fragment_builder(
    molecule_fragment_builder,
):
    def __init__(self):
        pass

