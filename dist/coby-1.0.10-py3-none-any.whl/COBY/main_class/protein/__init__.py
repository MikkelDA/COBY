'''
DOCSTRING TO BE WRITTEN
'''

from COBY.main_class.protein.protein_placer import *

class protein(
    protein_placer,
):
    def __init__(self):
        pass

