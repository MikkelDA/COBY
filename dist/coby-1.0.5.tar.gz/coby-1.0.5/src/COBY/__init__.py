'''
DOCSTRING TO BE WRITTEN
'''

from COBY.main_class.__init__ import *
from COBY.version import __version__, __version_changes__, __changes__, __changelog__
from COBY.citation import __doi__, __citation__