'''
DOCSTRING TO BE WRITTEN
'''

from COBY.main_class.solvation.get_solute_volume import *
from COBY.main_class.solvation.get_lipid_volume import *
from COBY.main_class.solvation.get_protein_volume import *
from COBY.main_class.solvation.solvater import *

class solvation(
    get_solute_volume,
    get_lipid_volume,
    get_protein_volume,
    solvater,
):
    def __init__(self):
        pass

