'''
DOCSTRING TO BE WRITTEN
'''

from COBY.main_class.lipid_inserter.lipid_inserter import *

class lipid_inserter(
    lipid_inserter,
):
    def __init__(self):
        pass

