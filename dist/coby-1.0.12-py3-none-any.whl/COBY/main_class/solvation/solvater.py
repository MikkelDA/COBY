import time
import math
import numpy as np
import random
import shapely
from operator import itemgetter
import copy
import itertools
from scipy.spatial.transform import Rotation as R

class solvater:
    def solvater(self):
        if len(self.SOLVATIONS_cmds) != 0:
            solvation_tic = time.time()
            string = " ".join(["", "SOLVATING SYSTEM", ""])
            self.print_term("{string:-^{string_length}}".format(string=string, string_length=self.terminalupdate_string_length), spaces=0, verbose=1)
            
            for solvation_i, (solvation_nr, solvation) in enumerate(self.SOLVATIONS.items()):
                if solvation_i != 0:
                    self.print_term("", verbose=2)
                self.print_term("Starting solvation nr", solvation_nr, spaces=0, verbose=2)

                #########################################
                ### CALCULATING FREE VOLUME OF SYSTEM ###
                #########################################
                self.print_term("Calculating box volume: (all values in [nm^3])", spaces=1, verbose=2)
                self.print_term("Bead radius used for volume calculations 'bead_radius':", solvation["bead_radius"]/10, "[nm]", spaces=2, verbose=2)

                bead_radius = solvation["bead_radius"]
                bead_volume = (4/3 * math.pi * (bead_radius ** 3)) * 10**-27
                
                cx_main, cy_main, cz_main = solvation["center"]
                xlen_main, ylen_main, zlen_main = itemgetter("xlength", "ylength", "zlength")(solvation)
                cxmin_main, cxmax_main = cx_main-xlen_main/2, cx_main+xlen_main/2
                cymin_main, cymax_main = cy_main-ylen_main/2, cy_main+ylen_main/2
                czmin_main, czmax_main = cz_main-zlen_main/2, cz_main+zlen_main/2
                solvent_box_centers = [cx_main, cy_main, cz_main]
                solvent_box_lengths = [xlen_main, ylen_main, zlen_main]
                main_insertion_box = (cxmin_main, cxmax_main, cymin_main, cymax_main, czmin_main, czmax_main)
                
                self.print_term("cx_main, cy_main, cz_main:", cx_main, cy_main, cz_main, debug=True, debug_keys=["solvater"])
                self.print_term("xlen_main, ylen_main, zlen_main:", xlen_main, ylen_main, zlen_main, debug=True, debug_keys=["solvater"])
                self.print_term("cxmin_main, cxmax_main:", cxmin_main, cxmax_main, debug=True, debug_keys=["solvater"])
                self.print_term("cymin_main, cymax_main:", cymin_main, cymax_main, debug=True, debug_keys=["solvater"])
                self.print_term("czmin_main, czmax_main:", czmin_main, czmax_main, debug=True, debug_keys=["solvater"])
                
                ### Solvent/solute volume
                solvent_beads_for_cell_checker, solvent_box_solute_charge = self.get_solute_volume(
                    cxmin_main, cxmax_main, cymin_main, cymax_main, czmin_main, czmax_main
                )
                
                ### Lipid volume
                lipid_beads_for_cell_checker, solvent_box_lipids_charge = self.get_lipid_volume(
                    cxmin_main, cxmax_main, cymin_main, cymax_main, czmin_main, czmax_main
                )

                ### Protein volume
                prot_beads_for_cell_checker, solvent_box_proteins_charge = self.get_protein_volume(
                    cxmin_main, cxmax_main, cymin_main, cymax_main, czmin_main, czmax_main
                )

                box_volume_extra = 0
                for cxmin_extra, cxmax_extra, cymin_extra, cymax_extra, czmin_extra, czmax_extra in solvation["extra_volume_box"] + solvation["extra_insertion_box"]:
                    ### Solvent/solute volume
                    solvent_beads_for_cell_checker_extra, solvent_box_solute_charge_extra = self.get_solute_volume(
                        cxmin_extra, cxmax_extra, cymin_extra, cymax_extra, czmin_extra, czmax_extra
                    )
                    
                    ### Lipid volume
                    lipid_beads_for_cell_checker_extra, solvent_box_lipids_charge_extra = self.get_lipid_volume(
                        cxmin_extra, cxmax_extra, cymin_extra, cymax_extra, czmin_extra, czmax_extra
                    )

                    ### Protein volume
                    prot_beads_for_cell_checker_extra, solvent_box_proteins_charge_extra = self.get_protein_volume(
                        cxmin_extra, cxmax_extra, cymin_extra, cymax_extra, czmin_extra, czmax_extra
                    )
                    solvent_beads_for_cell_checker += solvent_beads_for_cell_checker_extra
                    solvent_box_solute_charge += solvent_box_solute_charge_extra
                    
                    lipid_beads_for_cell_checker += lipid_beads_for_cell_checker_extra
                    solvent_box_lipids_charge += solvent_box_lipids_charge_extra
                    
                    prot_beads_for_cell_checker += prot_beads_for_cell_checker_extra
                    solvent_box_proteins_charge += solvent_box_proteins_charge_extra

                    box_volume_extra += (cxmax_extra - cxmin_extra) * (cymax_extra - cymin_extra) * (czmax_extra - czmin_extra) * 10**-27

                solvs_volume = bead_volume * len(solvent_beads_for_cell_checker)
                leafs_volume = bead_volume * len(lipid_beads_for_cell_checker)
                prots_volume = bead_volume * len(prot_beads_for_cell_checker)
                
                n_lipids = 0
                if solvation["solv_per_lipid"]:
                    if len(self.MEMBRANES) > 0:
                        ### Counts the number of lipids inside the solvent box
                        for memb_key, memb_dict in self.MEMBRANES.items():
                            for leaflet_key, leaflet in memb_dict["leaflets"].items():
                                for grid_point in leaflet["grid_lipids"]:
                                    xs, ys, zs = itemgetter("x", "y", "z")(grid_point["lipid"])
                                    beads_total = len(xs)
                                    beads_inside = 0
                                    for x, y, z in zip(xs, ys, zs):
                                        if cxmin_main < x <= cxmax_main and cymin_main < y <= cymax_main and czmin_main < z <= czmax_main:
                                            beads_inside += 1
                                        for cxmin_extra, cxmax_extra, cymin_extra, cymax_extra, czmin_extra, czmax_extra in solvation["extra_volume_box"] + solvation["extra_insertion_box"]:
                                            if cxmin_extra < x <= cxmax_extra and cymin_extra < y <= cymax_extra and czmin_extra < z <= czmax_extra:
                                                beads_inside += 1
                                    if beads_inside > beads_total * solvation["solv_per_lipid_cutoff"]:
                                        n_lipids += 1

                solvent_box_charge = solvent_box_solute_charge + solvent_box_lipids_charge + solvent_box_proteins_charge
                
                N_A = 6.02214076 * 10**23
                box_volume = (xlen_main * ylen_main * zlen_main) * 10**-27
                box_volume += box_volume_extra # 'box_volume_extra' is zero if no extra box volume specified.
                non_free_volume = leafs_volume + prots_volume + prots_volume
                box_free_volume = box_volume - non_free_volume
                self.print_term("Solvent box volume:", round(box_volume                    * 10**24, 3), spaces=2, verbose=2)
                if box_volume_extra:
                    self.print_term("Main box:", round((xlen_main * ylen_main * zlen_main) * 10**-27 * 10**24, 3), spaces=3, verbose=2)
                    self.print_term("Extra included volumes:", round(box_volume_extra      * 10**24, 3), spaces=3, verbose=2)
                
                self.print_term("Excluded volume:   ", round(non_free_volume               * 10**24, 3), spaces=2, verbose=2)
                
                self.print_term("Solute volume: ", round(solvs_volume                      * 10**24, 3), spaces=3, verbose=2)
                self.print_term("Lipid volume:  ", round(leafs_volume                      * 10**24, 3), spaces=3, verbose=2)
                self.print_term("Protein volume:", round(prots_volume                      * 10**24, 3), spaces=3, verbose=2)
                
                self.print_term("Free volume:       ", round(box_free_volume               * 10**24, 3), spaces=2, verbose=2)
                
                ###########################
                ### CALCULATING SOLVENT ###
                ###########################
                solvent_box_solvent_charge = 0

                def get_solvent_ratios(solvent_type_dict, tot_ratio):
                    ratios = [
                        round(1 / tot_ratio * vals.ratio, 4)
                        for key, vals in solvent_type_dict.items()
                    ]
                    return ratios
                
                if not solvation["count"]:
                    sol_ratios = get_solvent_ratios(solvation["solvent"], solvation["solv_tot_ratio"])
                    pos_ratios = get_solvent_ratios(solvation["pos_ions"], solvation["pos_tot_ratio"])
                    neg_ratios = get_solvent_ratios(solvation["neg_ions"], solvation["neg_tot_ratio"])
                else:
                    sol_ratios = [1 for _ in solvation["solvent"].keys()]
                    pos_ratios = [1 for _ in solvation["pos_ions"].keys()]
                    neg_ratios = [1 for _ in solvation["neg_ions"].keys()]

                def solvent_count_calculator(solvent_type, ratios, volume):

                    if solvent_type == "solvent":
                        molarity = solvation["solv_molarity"]
                    else:
                        molarity = solvation["salt_molarity"]
                    
                    N_A = 6.02214076 * 10**23
                    number_of_particles = N_A * volume * molarity

                    if solvation["count"]:
                        counts = [vals.molarity for vals in solvation[solvent_type].values()]
                    elif solvation["solv_per_lipid"] and solvent_type == "solvent":
                        ### Int rounding
                        counts = [int((solvation["solv_per_lipid"] * n_lipids * ratio)+0.5) for ratio in ratios]

                    elif solvation["ratio_method"] == "coarse":
                        ### Treats molarity as molarity
                        ### Ratios are treated as ratios between number of inserted CG molecules
                        mappings_weighted_mean = np.sum([vals.mapping_ratio * ratio for vals, ratio in zip(solvation[solvent_type].values(), ratios)])
                        ### Int rounding
                        counts = [int((number_of_particles * ratio / mappings_weighted_mean)+0.5) for ratio in ratios]

                    elif solvation["ratio_method"] == "atomistic":
                        ### Treats molarity as molarity
                        ### Ratios are treated as ratios between number of atoms (taking mapping ratio of solvent into account)
                        ### Int rounding
                        counts = [int((number_of_particles * ratio / vals.mapping_ratio)+0.5) for vals, ratio in zip(solvation[solvent_type].values(), ratios)]

                    return counts
                
                volume_for_solv = box_free_volume
                ### Using the free volume for concentration calculations (default)
                if solvation["solvfreevol"] == True:
                    volume_for_solv = box_free_volume
                ### Using box volume for concentration calculations
                elif solvation["solvfreevol"] == False:
                    volume_for_solv = box_volume
                
                sol_counts = solvent_count_calculator(
                    "solvent",
                    sol_ratios,
                    volume_for_solv,
                )
                
                solv_volume = 0
                sol_charges = 0

                for (key, vals), count in zip(solvation["solvent"].items(), sol_counts):
                    vals.count_set(count)
                    sol_charges += vals.count * vals.get_mol_charge()
                    ### Only throws warnings if you are actually trying to insert ions
                    if solvation["pos_ions"] and solvation["neg_ions"]:
                        if not vals.molar_mass and solvation["ionsvol"] == "solv" and not solvation["count"]:
                            self.print_term("WARNING: Chosen solvent [" + key + "] is missing a 'molar_mass' entry in the solvent defines. Please add it if you wish to use solvent volume for ion concentration.", warn = True)
                        if not vals.density and solvation["ionsvol"] == "solv" and not solvation["count"]:
                            self.print_term("WARNING: Chosen solvent [" + key + "] is missing a 'density' entry in the solvent defines. Please add it if you wish to use solvent volume for ion concentration.", warn = True)
                        if vals.molar_mass and vals.density:
                            solv_volume += (count * vals.mapping_ratio * vals.molar_mass) / (N_A * vals.density) * 10**-3
                
                self.print_term("Solvent volume:    ", round(solv_volume * 10**24, 3), spaces=2, verbose=2)

                solvent_box_solvent_charge += sol_charges

                def ions_neutraliser(pos_ions, neg_ions, target_charge, current_charge, direction):
                    charge_difference = target_charge - current_charge
                    if charge_difference > 0:
                        ions = pos_ions
                    elif charge_difference < 0:
                        ions = neg_ions
                    else:
                        return pos_ions, neg_ions
                    
                    if direction == "add":
                        sign = +1
                    if direction == "remove":
                        sign = -1
                    
                    keys = list(ions.keys())
                    keys_sorted_after_ratio = list(sorted(keys, key=lambda key: ions[key]["ratio"], reverse = True))
                    tot_ions = sum([vals["count"] for vals in ions.values()])
                    counter = 0
                    while round(current_charge) != round(target_charge):
                        counter += 1
                        ### Find which ion is furthest from ideal ratio
                        if tot_ions == 0:
                            ### No ions yet, just sort them from highest to lowest ratio
                            furthest_dist_keys = keys_sorted_after_ratio[::sign]
                        else:
                            ### Calculate how far each ion is from its ideal ratio
                            dists_from_ratio = []
                            for key, vals in list(ions.items()):
                                dists_from_ratio.append((key, vals["count"]/tot_ions - vals["ratio"]))
                            ### Sort them from most underrepresented to most overrepresented
                            ### Secondarily sort them according to their ideal ratios in case the are equally underrepresented
                            dists_from_ratio_sorted = sorted(
                                dists_from_ratio,
                                key=lambda x: (x[1], keys_sorted_after_ratio.index(x[0])),
                                reverse = False
                            )
                            ### Get just the keys
                            furthest_dist_keys = [key for key, dist_from_ratio in dists_from_ratio_sorted][::sign]
                        
                        ### Checks from most underrepresented to most overrepresented if adding another ion
                        ### would cause the total added charge to become greater than the difference that is being corrected
                        for key in furthest_dist_keys:
                            if abs(target_charge - current_charge) >= abs(ions[key]["charge"]):
                                furthest_dist_key = key
                                break
                        else:
                            ### If an ion should be added but no ion can be added without adding
                            ### more charge than is needed for neutralization
                            ### then just return as is
                            return pos_ions, neg_ions
                        
                        tot_ions += sign
                        current_charge += ions[furthest_dist_key]["charge"]
                        ions[furthest_dist_key]["count"] += sign
                        
                    return pos_ions, neg_ions
                
                ### Sets default volume for ions to box free volume
                volume_for_ions = box_free_volume
                ### Using the solvent volume for concentration calculations
                if solvation["ionsvol"] == "solv" and solv_volume > 0 and not solvation["count"]:
                    volume_for_ions = solv_volume
                ### Using the free volume for concentration calculations
                elif solvation["ionsvol"] == "free" or (solvation["ionsvol"] == "solv" and solvation["count"]):
                    volume_for_ions = box_free_volume
                ### Using the box volume for concentration calculations
                elif solvation["ionsvol"] == "box":
                    volume_for_ions = box_volume
                    
                ### Only runs ion-specific calculations if both positive and negative ions are designated.
                if pos_ratios and neg_ratios:
                    ### First ensures that the ion concentration is equal to salt_molarity
                    pos_counts = solvent_count_calculator(
                        "pos_ions",
                        pos_ratios,
                        volume_for_ions
                    )
                
                    neg_counts = solvent_count_calculator(
                        "neg_ions",
                        neg_ratios,
                        volume_for_ions
                    )
                    
                    pos_charges = 0
                    neg_charges = 0
                    
                    ions_dict = {}
                    zipped1 = zip(["pos_ions", "neg_ions"], [pos_counts, neg_counts], [pos_ratios, neg_ratios])
                    for ion_type, ion_counts, ion_ratios in zipped1:
                        ions_dict[ion_type] = {}
                        zipped2 = zip(solvation[ion_type].items(), ion_counts, ion_ratios)
                        for (key, vals), count, ratio in zipped2:
                            vals.count_set(count)
                            if ion_type == "pos_ions":
                                pos_charges += vals.count * vals.get_mol_charge()
                            elif ion_type == "neg_ions":
                                neg_charges += vals.count * vals.get_mol_charge()
                            ions_dict[ion_type][key] = {
                                "charge": vals.get_mol_charge(),
                                "ratio": ratio,
                                "count": vals.count,
                            }
                    
                    current_charge = round(solvent_box_charge + sol_charges + pos_charges + neg_charges, 5)
                    
                    pos_charges = 0
                    neg_charges = 0
                    
                    if solvation["salt_method"] == "add":
                        '''
                        Adds extra ions to neutralize the solvent box
                        '''
                        pos_ions, neg_ions = ions_neutraliser(
                            ions_dict["pos_ions"],
                            ions_dict["neg_ions"],
                            solvation["target_charge"],
                            current_charge,
                            direction = "add",
                        )
                        zipped = zip(["pos_ions", "neg_ions"], [pos_ions, neg_ions])
                        for ion_type, ions_dicts in zipped:
                            for (key, vals), (ions_dict_key, ions_dict_vals) in zip(solvation[ion_type].items(), ions_dicts.items()):
                                vals.count_set(ions_dict_vals["count"])

                    elif solvation["salt_method"] == "remove":
                        '''
                        Removes excess ions to neutralize the solvent box
                        '''
                        pos_ions, neg_ions = ions_neutraliser(
                            ions_dict["pos_ions"],
                            ions_dict["neg_ions"],
                            solvation["target_charge"],
                            -current_charge,
                            direction = "remove",
                        )
                        zipped = zip(["pos_ions", "neg_ions"], [pos_ions, neg_ions])
                        for ion_type, ions_dicts in zipped:
                            for (key, vals), (ions_dict_key, ions_dict_vals) in zip(solvation[ion_type].items(), ions_dicts.items()):
                                vals.count_set(ions_dict_vals["count"])
                        
                    elif solvation["salt_method"] == "mean":
                        '''
                        Adds ions with either a positive or negative charge and removes the other type
                        Ends up with ion concentrations in between "add" and "remove"
                        Does an extra ion addition at the end to ensure no errors have been made when
                            adding/removing ions.
                        '''
                        ### Need to deepcopy, otherwise the nested dictionaries will be modified 
                        ions_dict_add = copy.deepcopy(ions_dict)
                        pos_ions_add, neg_ions_add = ions_neutraliser(
                            ions_dict_add["pos_ions"],
                            ions_dict_add["neg_ions"],
                            solvation["target_charge"],
                            +math.ceil(current_charge/2),
                            direction = "add",
                        )
                        ions_dict_remove = copy.deepcopy(ions_dict)
                        pos_ions_remove, neg_ions_remove = ions_neutraliser(
                            ions_dict_remove["pos_ions"],
                            ions_dict_remove["neg_ions"],
                            solvation["target_charge"],
                            -math.floor(current_charge/2),
                            direction = "remove",
                        )
                        
                        zipped1 = zip(["pos_ions", "neg_ions"],
                                    [pos_counts, neg_counts],
                                    [pos_ions_add, neg_ions_add],
                                    [pos_ions_remove, neg_ions_remove])
                        for ion_type, ion_counts, ions_dicts_add, ions_dicts_remove in zipped1:
                            zipped2 = zip(solvation[ion_type].items(),
                                        ion_counts,
                                        ions_dicts_add.values(),
                                        ions_dicts_remove.values())
                            for (key, vals), count, ions_dict_add_vals, ions_dict_remove_vals in zipped2:
                                add_diff = abs(count - ions_dict_add_vals["count"])
                                rem_diff = abs(count - ions_dict_remove_vals["count"])
                                vals.count_set(count + add_diff - rem_diff)

                    ### Extra ion addtion to prevent errors (e.g. non-neutralized systems)
                    ions_dict = {}
                    for ion_type, ion_ratios in zip(["pos_ions", "neg_ions"], [pos_ratios, neg_ratios]):
                        ions_dict[ion_type] = {}
                        for (key, vals), ratio in zip(solvation[ion_type].items(), ion_ratios):
                            
                            ### Checks if negative number of the ion should be inserted and set to zero if it is the case.
                            ### ### Done incase "remove" or "mean" methods have removed more ions than should even be present.
                            if vals.count < 0:
                                vals.count_set(0)

                            ions_dict[ion_type][key] = {
                                "charge": vals.get_mol_charge(),
                                "ratio": ratio,
                                "count": vals.count,
                            }

                            if ion_type == "pos_ions":
                                pos_charges += vals.count * vals.get_mol_charge()
                            elif ion_type == "neg_ions":
                                neg_charges += vals.count * vals.get_mol_charge()
                    
                    current_charge = solvent_box_charge + sol_charges + pos_charges + neg_charges

                    pos_ions, neg_ions = ions_neutraliser(
                        ions_dict["pos_ions"],
                        ions_dict["neg_ions"],
                        solvation["target_charge"],
                        current_charge,
                        direction = "add",
                    )

                    pos_charges = 0
                    neg_charges = 0

                    for ion_type, ions_dicts in zip(["pos_ions", "neg_ions"], [pos_ions, neg_ions]):
                        for (key, vals), (ions_dict_key, ions_dict_vals) in zip(solvation[ion_type].items(), ions_dicts.items()):
                            vals.count_set(ions_dict_vals["count"])
                            if ion_type == "pos_ions":
                                pos_charges += vals.count * vals.get_mol_charge()
                            elif ion_type == "neg_ions":
                                neg_charges += vals.count * vals.get_mol_charge()
                    
                    solvent_box_solvent_charge += pos_charges + neg_charges

                ### Adding charges from ions and solvent to system charge
                self.system_charge += solvent_box_solvent_charge
                
                self.print_term("", verbose=2)
                self.print_term("Solvent box charge information:",                                            spaces=1, verbose=2)
                self.print_term("Solvent box charge before solvent insertion:", round(solvent_box_charge, 1), spaces=2, verbose=2)
                self.print_term("Prior solvent beads: ", round(solvent_box_solute_charge, 1),                 spaces=3, verbose=2)
                self.print_term("Lipid beads:         ", round(solvent_box_lipids_charge, 1),                 spaces=3, verbose=2)
                self.print_term("Protein beads:       ", round(solvent_box_proteins_charge, 1),               spaces=3, verbose=2)
                solvent_box_charge += solvent_box_solvent_charge
                self.print_term("Solvent box charge after solvent insertion: ", round(solvent_box_charge, 1), spaces=2, verbose=2)
                self.print_term("New solvent beads:", round(solvent_box_solvent_charge, 1),                   spaces=3, verbose=2)
                self.print_term("Solvent       (solv):", round(sol_charges, 1),                               spaces=4, verbose=2)
                if solvation["pos_ions"]:
                    self.print_term("Positive ions (pos): ", round(pos_charges, 1),                               spaces=4, verbose=2)
                if solvation["neg_ions"]:
                    self.print_term("Negative ions (neg): ", round(neg_charges, 1),                               spaces=4, verbose=2)

                ### Randomly shuffle solvent particles for random distribution in box
                ### Finding number of particles here to prevent extra calls to "get_res_beads_info()" later
                collected_solvent = []
                solvation["solv_count"] = {}
                for stype in ["solvent", "pos_ions", "neg_ions"]:
                    for key, vals in solvation[stype].items():
                        sname = key
                        snbeads = len(vals.get_res_beads_info())
                        scharge = vals.get_mol_charge()
                        scount = vals.count
                        collected_solvent.extend([[sname, stype, snbeads]] * scount)
                        solvation["solv_count"][(sname, stype, scharge)] = scount

                ##############################################
                ### RUNNING SOLVENT OPTIMIZATION ALGORITHM ###
                ##############################################

                def molecule_extent_under_rotations(coords, max_angles):
                    step = 1
                    angle_options = {
                        "x": np.arange(max_angles[0][0], max_angles[0][1] + step, step),
                        "y": np.arange(max_angles[1][0], max_angles[1][1] + step, step),
                        "z": np.arange(max_angles[2][0], max_angles[2][1] + step, step)
                    }

                    rotations_x = [(x, 0, 0) for x in angle_options['x']]
                    rotations_y = [(0, y, 0) for y in angle_options['y']]
                    rotations_z = [(0, 0, z) for z in angle_options['z']]

                    rotations = rotations_x + rotations_y + rotations_z

                    max_molecule_axial_extents = np.zeros(3)

                    for angles in rotations:
                        rot                        = R.from_euler('xyz', angles, degrees=True)
                        rotated                    = rot.apply(coords)
                        molecule_axial_extents     = rotated.max(axis=0) - rotated.min(axis=0)
                        max_molecule_axial_extents = np.maximum(max_molecule_axial_extents, molecule_axial_extents)

                    return max_molecule_axial_extents
                
                ### List used to find the maximum solvent/ion size along each axis
                molecules_in_solvation = [
                    molecule.get_beads()
                    for dict_pointer in ["solvent", "pos_ions", "neg_ions"]
                    for molecule in solvation[dict_pointer].values()
                ]

                molecules_max_axial_extents = []
                for molecule in molecules_in_solvation:
                    ### Only check for rotations if the molecule contains multiple beads. No point in checking it for single-bead molecules.
                    if len(molecule) > 1:
                        molecules_max_axial_extents.append(tuple(molecule_extent_under_rotations(np.array(molecule), solvation["rotation_angles"])))
                    else:
                        molecules_max_axial_extents.append((0, 0, 0))

                ### Finds the maximum size of molecules used as solvent/ions
                ### Also includes buffer/kick size to prevent edge overlap cases
                max_mol_sizes = [max(molecule_extents_per_axis) for molecule_extents_per_axis in zip(*molecules_max_axial_extents)]
                
                self.print_term('solvation["rotation_angles"]:', solvation["rotation_angles"],           debug=True, debug_keys=["solvater"])
                self.print_term("molecules_max_axial_extents: ", molecules_max_axial_extents,            debug=True, debug_keys=["solvater"])
                self.print_term("max_mol_sizes:               ", max_mol_sizes,                          debug=True, debug_keys=["solvater"])
                self.print_term("max_mol_sizes*1.2:           ", [val*1.2 for val in max_mol_sizes],     debug=True, debug_keys=["solvater"])
                self.print_term("kick:                        ", solvation["kick"],                      debug=True, debug_keys=["solvater"])
                self.print_term("kick*2.2:                    ", [val*2.2 for val in solvation["kick"]], debug=True, debug_keys=["solvater"])
                
                original_gridres = solvation["gridres"].copy()
                gridres = solvation["gridres"].copy()
                
                self.print_term("gridres first:               ", solvation["gridres"], debug=True, debug_keys=["solvater"])
                
                ### if 'the largest molecule + 2*kick' is bigger than the designated grid resolution then change the gridres
                axes = ["x", "y", "z"]
                for i in range(len(gridres)):
                    if (max_mol_sizes[i]+solvation["kick"][i]*2) >= gridres[i]:
                        gridres[i] = (max_mol_sizes[i] + solvation["kick"][i]*2)*1.2 # 20% extra
                        self.print_term("Requested solvent is too large for the grid resolution for axis '{axis}'. Adjusting grid resolution to prevent molecule overlaps.".format(axis=axes[i]), warn = True)
                        self.print_term("Original grid resolution was:", round(original_gridres[i]/10, 4), "[nm]", warn = True)
                        self.print_term("New grid resolution is:      ", round(gridres[i]/10, 4), "[nm]", warn = True)
                        self.print_term("Calculation: ('largest molecule size along the {axis}-axis' + 2 * 'particle kick value') * 1.2".format(axis=axes[i]), "\n",  warn = True)

                self.print_term("gridres last:                ", gridres, debug=True, debug_keys=["solvater"])
                
                solvent_buffer = solvation["buffer"]

                #################################
                ### CHOOSES ALGORITHM VERSION ###
                #################################
                self.print_term("", verbose=2)
                self.print_term("Calculating the number of available grid points", spaces=1, verbose=2)

                def coord_to_indices(pos, dim, center, real_gridres, min_buffer, max_buffer):
                    ### Buffer limit
                    bead_min = pos-min_buffer
                    bead_max = pos+max_buffer

                    ### Convert solvent buffer limit to decimal index
                    beadi_min_dec = (bead_min+dim/2-center)/real_gridres
                    beadi_max_dec = (bead_max+dim/2-center)/real_gridres

                    ### Round buffer decimal index to integer index
                    beadi_min_int = int(beadi_min_dec)
                    beadi_max_int = int(beadi_max_dec)+1 # +1 due to last index not being counted
                    
                    if beadi_min_int < 0:
                        beadi_min_int = 0
                    if beadi_max_int < 0:
                        beadi_max_int = 0
                        
                    return beadi_min_int, beadi_max_int
                
                enough_grid_points = False
                while not enough_grid_points:
                    solv_grid_3D = []
                    insertion_boxes = [(main_insertion_box, "Main insertion box")] + [(i, "Extra insertion box") for i in solvation["extra_insertion_box"]]
                    for boxi, ((cxmin, cxmax, cymin, cymax, czmin, czmax), box_type) in enumerate(insertion_boxes):
                        cx, cy, cz = (cxmax + cxmin)/2, (cymax + cymin)/2, (czmax + czmin)/2
                        xlen, ylen, zlen = cxmax - cxmin, cymax - cymin, czmax - czmin
                        
                        xpoints, ypoints, zpoints = int(xlen/gridres[0]), int(ylen/gridres[1]), int(zlen/gridres[2])
                        ### Calculates actual coordinate ranges for each axis and calculates the "real" grid resolution
                        xcoords, xreal_gridres = np.linspace(cxmin-gridres[0]/2, cxmax+gridres[0]/2, xpoints+2, retstep=True)
                        ycoords, yreal_gridres = np.linspace(cymin-gridres[1]/2, cymax+gridres[1]/2, ypoints+2, retstep=True)
                        zcoords, zreal_gridres = np.linspace(czmin-gridres[2]/2, czmax+gridres[2]/2, zpoints+2, retstep=True)
                        ### Removes the first and last points as they are the actual edges of the box
                        xcoords = xcoords[1:-1]
                        ycoords = ycoords[1:-1]
                        zcoords = zcoords[1:-1]
                        
                        solute_buffer  = solvent_buffer+solvation["solute_extra_buffer"]
                        lipid_buffer   = solvent_buffer+solvation["lipid_extra_buffer"]
                        protein_buffer = solvent_buffer+solvation["protein_extra_buffer"]
                        
                        ### Separate if-statement for debug mode prevents a lot of calls to the self.print_term() method
                        if self.debug_prints == True and (len(self.debug_keys) == 0 or "solvater" in self.debug_keys):
                            self.print_term("Box type (box nr):", box_type, "("+str(boxi)+")",           spaces=0, debug=True, debug_keys=["solvater"])

                            self.print_term("cxmin, cxmax          :", round(cxmin, 3), round(cxmax, 3), spaces=1, debug=True, debug_keys=["solvater"])
                            self.print_term("cymin, cymax          :", round(cymin, 3), round(cymax, 3), spaces=1, debug=True, debug_keys=["solvater"])
                            self.print_term("czmin, czmax          :", round(czmin, 3), round(czmax, 3), spaces=1, debug=True, debug_keys=["solvater"])
                            self.print_term("xpoints, xreal_gridres:", xpoints, round(xreal_gridres, 4), spaces=1, debug=True, debug_keys=["solvater"])
                            self.print_term("ypoints, yreal_gridres:", ypoints, round(yreal_gridres, 4), spaces=1, debug=True, debug_keys=["solvater"])
                            self.print_term("zpoints, zreal_gridres:", zpoints, round(zreal_gridres, 4), spaces=1, debug=True, debug_keys=["solvater"])
                            self.print_term("points total          :", xpoints*ypoints*zpoints,          spaces=1, debug=True, debug_keys=["solvater"])
                            self.print_term("solvent_buffer        :", solvent_buffer,                   spaces=1, debug=True, debug_keys=["solvater"])
                            self.print_term('solvation["buffer"]   :', solvent_buffer,                   spaces=1, debug=True, debug_keys=["solvater"])
                            self.print_term("solute_buffer         :", solute_buffer,                    spaces=1, debug=True, debug_keys=["solvater"])
                            self.print_term("lipid_buffer          :", lipid_buffer,                     spaces=1, debug=True, debug_keys=["solvater"])
                            self.print_term("protein_buffer        :", protein_buffer,                   spaces=1, debug=True, debug_keys=["solvater"])
                        
                        ### Creates a 3D matrix indicating the points in space that are allowed to have solvent
                        ### Starts out being completely filled with ones indicating allowed space
                        grid_bool_matrix = np.ones((xpoints, ypoints, zpoints), dtype=np.int8)
                        
                        ### ### Marks coordinates as "occupied" by setting boolean to False
                        ### Marks points located in hydrophobic volume
                        if len(self.MEMBRANES) != 0:
                            for memb_key, memb_dict in self.MEMBRANES.items():
                                for leaflet_key, leaflet in memb_dict["leaflets"].items():
                                    if leaflet["solvate_hydrophobic_volume"] == False or solvation["solvate_hydrophobic_volume"] == False:
                                        lcz = leaflet["center"][2]
                                        ### Z-related stuff is always the same for all subleaflets
                                        if leaflet["HG_direction"] == "up":
                                            zminbuffer = solvent_buffer
                                            zmaxbuffer = leaflet["lipid_dimensions"]["min_max_zs"] + solvent_buffer
                                        if leaflet["HG_direction"] == "down":
                                            ### Also "min_max_zs" here as the lipid dimensions are done for a generalized upwards pointing lipid
                                            ### It is subtracted inside coord_to_indices()
                                            zminbuffer = leaflet["lipid_dimensions"]["min_max_zs"] + solvent_buffer
                                            zmaxbuffer = solvent_buffer
                                        zmin, zmax = coord_to_indices(lcz, zlen, cz, zreal_gridres, zminbuffer, zmaxbuffer)
                                        
                                        ### Advanced (and slower) solvent-in-membrane prevention method
                                        ### Creates a series of points in 2D and marks matrix coordinates one point at a time
                                        ### Allows holes to be solvated
                                        if leaflet["solvate_hole"] and any([leaflet["remove_union_without_protein"], leaflet["require_union"], leaflet["inside_protein"]]):
                                            geoms = self.get_geoms_list(leaflet["holed_bbox_without_protein_removed"])
                                            for geom in geoms:
                                                poly_xmin, poly_ymin, poly_xmax, poly_ymax = geom.bounds
                                                lcx = np.mean([poly_xmax, poly_xmin])
                                                lcy = np.mean([poly_ymax, poly_ymin])
                                                llx = poly_xmax - poly_xmin
                                                lly = poly_ymax - poly_ymin

                                                xmin_i, xmax_i = coord_to_indices(lcx, xlen, cx, xreal_gridres, llx/2, llx/2)
                                                ymin_i, ymax_i = coord_to_indices(lcy, ylen, cy, yreal_gridres, lly/2, lly/2)
                                                xcoords_in_leaflet = xcoords[xmin_i:xmax_i+1]
                                                ycoords_in_leaflet = ycoords[ymin_i:ymax_i+1]

                                                points_to_check = [(round(x, 3), round(y, 3)) for x in xcoords_in_leaflet for y in ycoords_in_leaflet]
                                                Points_to_check = [shapely.Point(point) for point in points_to_check]
                                                
                                                geom_buffered = shapely.buffer(geom, solvent_buffer)
                                                points_contained_bools = geom_buffered.contains(Points_to_check)
                                                points_in_geom = [point for point, point_bool in zip(points_to_check, points_contained_bools) if point_bool]
                                                
                                                for lcx, lcy in points_in_geom:
                                                    xmin, xmax = coord_to_indices(lcx, xlen, cx, xreal_gridres, solvent_buffer, solvent_buffer)
                                                    ymin, ymax = coord_to_indices(lcy, ylen, cy, yreal_gridres, solvent_buffer, solvent_buffer)
                                                    grid_bool_matrix[xmin:xmax, ymin:ymax, zmin:zmax] = 0

                                        ### Simple (and fast) solvent-in-membrane prevention method
                                        ### Simply marks all matrix coordinates overlapping with the membrane
                                        ### Prevents holes from being solvated
                                        else:
                                            lcx, lcy = leaflet["center"][:2] # Center of leaflet on given axis
                                            llx, lly = leaflet["xlength"], leaflet["ylength"] # Length of leaflet in given axis
                                            xmin, xmax = coord_to_indices(lcx, xlen, cx, xreal_gridres, llx/2, llx/2)
                                            ymin, ymax = coord_to_indices(lcy, ylen, cy, yreal_gridres, lly/2, lly/2)
                                            grid_bool_matrix[xmin:xmax, ymin:ymax, zmin:zmax] = 0

                        ### Prior solvent beads
                        for xpos, ypos, zpos in solvent_beads_for_cell_checker:
                            ### Checks if any non-solvent bead is within the solvent cell
                            xmin, xmax = coord_to_indices(xpos, xlen, cx, xreal_gridres, solute_buffer, solute_buffer)
                            ymin, ymax = coord_to_indices(ypos, ylen, cy, yreal_gridres, solute_buffer, solute_buffer)
                            zmin, zmax = coord_to_indices(zpos, zlen, cz, zreal_gridres, solute_buffer, solute_buffer)
                            grid_bool_matrix[xmin:xmax, ymin:ymax, zmin:zmax] = 0

                        ### Lipid beads
                        for xpos, ypos, zpos in lipid_beads_for_cell_checker:
                            ### Checks if any lipid bead is within the solvent cell
                            xmin, xmax = coord_to_indices(xpos, xlen, cx, xreal_gridres, lipid_buffer, lipid_buffer)
                            ymin, ymax = coord_to_indices(ypos, ylen, cy, yreal_gridres, lipid_buffer, lipid_buffer)
                            zmin, zmax = coord_to_indices(zpos, zlen, cz, zreal_gridres, lipid_buffer, lipid_buffer)
                            grid_bool_matrix[xmin:xmax, ymin:ymax, zmin:zmax] = 0

                        ### Protein beads
                        for xpos, ypos, zpos in prot_beads_for_cell_checker:
                            ### Checks if any protein bead is within the solvent cell
                            xmin, xmax = coord_to_indices(xpos, xlen, cx, xreal_gridres, protein_buffer, protein_buffer)
                            ymin, ymax = coord_to_indices(ypos, ylen, cy, yreal_gridres, protein_buffer, protein_buffer)
                            zmin, zmax = coord_to_indices(zpos, zlen, cz, zreal_gridres, protein_buffer, protein_buffer)
                            
                            grid_bool_matrix[xmin:xmax, ymin:ymax, zmin:zmax] = 0
                        
                        ### Gets all the indices that are not occupied
                        free_indices = grid_bool_matrix.nonzero()
                        free_xs, free_ys, free_zs = free_indices
                        free_xs_coords = xcoords[free_xs]
                        free_ys_coords = ycoords[free_ys]
                        free_zs_coords = zcoords[free_zs]
                        
                        solv_grid_3D.extend(list(zip(free_xs_coords, free_ys_coords, free_zs_coords)))
                    
                    if len(solv_grid_3D) >= len(collected_solvent):
                        enough_grid_points = True
                    else:
                        self.print_term("Number of available grid points ({GP}) is less than number of molecules to be inserted ({NS}).".format(GP=len(solv_grid_3D), NS=len(collected_solvent)), warn=True)
                        self.print_term("Reducing grid size (resolution) by 5% and recalculating grid occupancy.", warn=True)
                        self.print_term("    ", "Old: {GR}".format(GR=gridres), warn=True)
                        gridres = [val * 0.95 for val in gridres]
                        self.print_term("    ", "New: {GR}".format(GR=gridres), warn=True)
                        
                        if any([val < max_mol_size for val, max_mol_size in zip(gridres, max_mol_sizes)]):
                            if solvation["flooding"]:
                                self.print_term("New grid resolution is very small compared to the largest molecule. This will likely result in overlapping molecules. Consider changing the the number of molecules '{nmolecules}' or kick values '{kick}'.".format(nmolecules=len(collected_solvent), kick=solvation["kick"]), warn=True)
                            else:
                                self.print_term("New grid resolution is very small compared to the largest molecule. This will likely result in overlapping molecules. Consider changing the solvent molarity '{solv_molarity}' or kick values '{kick}'.".format(solv_molarity=solvation["solv_molarity"], kick=solvation["kick"]), warn=True)
                            self.print_term("Grid resolution along each axis:       {x}, {y}, {z}.".format(x=gridres[0], y=gridres[1], z=gridres[2]), spaces=1, warn=True)
                            self.print_term("Largest molecule size along each axis: {x}, {y}, {z}.".format(x=max_mol_sizes[0], y=max_mol_sizes[1], z=max_mol_sizes[2]), spaces=1, warn=True)

                self.print_term("Final number of 3D grid points available for molecule placement:", len(solv_grid_3D), spaces=2, verbose=2)

                ################################
                ### INSERT SOLVENT MOLECULES ###
                ################################

                def position_fixer(coords, ax_i):
                    '''
                    Checking if any beads are outside the solvent box and moves them if they are.
                    If all beads are outside: Moved to other side of pbc.
                    If at least 1 bead is inside: All beads are pushed slightly so that they are inside the pbc.
                    '''
                
                    ax_max = solvent_box_centers[ax_i] + solvent_box_lengths[ax_i]/2
                    ax_min = solvent_box_centers[ax_i] - solvent_box_lengths[ax_i]/2
                    outside_counter = 0
                    exceeds_bounds_direction = None
                    differences = []
                    
                    for pos in coords:
                        pos = pos
                        if pos > ax_max:
                            outside_counter += 1
                            exceeds_bounds_direction = "positive"
                            ### Below value is always positive because of "pos > ax_max"
                            differences.append(pos - ax_max)
                            
                        elif pos < ax_min:
                            outside_counter += 1
                            exceeds_bounds_direction = "negative"
                            ### Below value is always negative because of "pos < ax_min"
                            differences.append(pos - ax_min)

                    new_coords = []
                    if outside_counter > 0:
                        if exceeds_bounds_direction == "positive":
                            difference = max(differences)
                            new_coords = [coord - difference - 0.001 for coord in coords] # - 0.001 to ensure it doesnt end up just outside the box due to float shenanigans
                        elif exceeds_bounds_direction == "negative":
                            difference = min(differences)
                            new_coords = [coord - difference + 0.001 for coord in coords] # + 0.001 to ensure it doesnt end up just outside the box due to float shenanigans
                        
                        return new_coords
                    else:
                        return coords

                self.print_term("Inserting", len(collected_solvent), "solvent molecules into random grid points:", spaces=2, verbose=2)
                self.print_term("number of grid points:", len(solv_grid_3D), debug=True, debug_keys=["solvater"])
                self.print_term("number of solvent:    ", len(collected_solvent), debug=True, debug_keys=["solvater"])

                assert len(solv_grid_3D) >= len(collected_solvent), "\n".join([
                    "Too few 3D-grid points available for solvent insertion.",
                    "3D Grid points:                     " + str(len(solv_grid_3D)),
                    "Solvent molecules (including ions): " + str(len(collected_solvent)),
                    "Either reduce solvent or salt concentration 'solv_molarity' / 'salt_molarity' or make grid resolution value smaller 'gridres'",
                    "If you are using the 'solvation' argument but are trying to flood the system, then try using the 'flooding' argument instead",
                ])
                
                ### random.sample extracts k random elements from the list without duplicates
                random_grid_points = random.sample(solv_grid_3D, k = len(collected_solvent))

                ### Calculating kicks first might be faster for large number of solvent
                kick = solvation["kick"]
                kxs = [random.uniform(-kick[0], kick[0]) for _ in range(len(collected_solvent))]
                kys = [random.uniform(-kick[1], kick[1]) for _ in range(len(collected_solvent))]
                kzs = [random.uniform(-kick[2], kick[2]) for _ in range(len(collected_solvent))]
                kicks = zip(kxs, kys, kzs)

                ### Unpacking rotation angles because finding values in a dictionary is slower
                x_rotation_angles, y_rotation_angles, z_rotation_angles = solvation["rotation_angles"]

                grid_solvated = []
                stype_order_dict = {"solvent": 1, "pos_ions": 2, "neg_ions": 3}
                counter = 0 # Prevents crash in case collected_solvent has length of 0
                for counter, ((sname, stype, snbeads), (gx, gy, gz), (kx, ky, kz)) in enumerate(zip(collected_solvent, random_grid_points, kicks), 1):
                    '''
                    Finds a 3D-grid point for the solvent and places it there.
                    '''
                    if counter == 1 or counter % 25000 == 0:
                        self.print_term("Currently at solvent number:", counter, spaces=3, verbose=2)
                    sdata = solvation[stype][sname]
                    sinfo = sdata.get_res_beads_info()
                    
                    sbeads       = [bead.bead for bead in sinfo]
                    sresnames    = [bead.resname for bead in sinfo]
                    sbeadcharges = [bead.charge for bead in sinfo]
                    scharge      = sdata.get_mol_charge()
                    sx, sy, sz   = sdata.get_coords("xyz")

                    ### Only makes sense to rotate if molecule contains more than 1 bead
                    if snbeads > 1:
                        rx   = random.uniform(*x_rotation_angles)
                        ry   = random.uniform(*y_rotation_angles)
                        rz   = random.uniform(*z_rotation_angles)
                        
                        for j, (x, y, z) in enumerate(zip(sx, sy, sz)):
                            sx[j], sy[j], sz[j] = self.rotate_point(x, y, z, rx, ry, rz)
                    
                    for j, (x, y, z) in enumerate(zip(sx, sy, sz)):
                        sx[j], sy[j], sz[j] = sx[j] + kx + gx, sy[j] + ky + gy, sz[j] + kz + gz

                    ### Squeezing of the grid resolution can cause beads to end up outside the solvent box
                    ### Places them back inside
                    sx = position_fixer(sx, 0)
                    sy = position_fixer(sy, 1)
                    sz = position_fixer(sz, 2)

                    ### Order that beads should be written in structure and topology files
                    ### if/elif faster than dictionary lookup due to most molecules (roughly 95-99%) being "solvent"
                    order = stype_order_dict[stype]

                    grid_solvated.append({
                        "order":        order,
                        "name":         sname,
                        "resnames":     sresnames,
                        "type":         stype,
                        "beads":        sbeads,
                        "bead_charges": sbeadcharges,
                        "charge":       scharge,
                        "coords":       list(zip(sx, sy, sz)),
                    })

                    self.solvent_beads_in_sys += len(sbeads)

                self.print_term("Currently at solvent number:", counter, spaces=3, verbose=2)

                ### Orders the solvent key:value pairs to ensure topology-structure file match
                solvation["grid"] = sorted(grid_solvated, key=lambda g: (g["order"], g["name"], g["charge"]))
                solvation["solv_count"] = {
                    key: solvation["solv_count"][key]
                    for key
                    in sorted(
                        solvation["solv_count"].keys(),
                        ### Sort order: stype, name, charge
                        key=lambda s: (stype_order_dict[s[1]], s[0], s[2])
                    )
                }
                
                if solvation_i == 0:
                    SYS_solv_count = {}
                    SYS_solv_volume = solv_volume
                else:
                    SYS_solv_volume += solv_volume
                
                CMD_solv_count = {}
                for (sname, stype, scharge), count in solvation["solv_count"].items():
                    '''
                    Counts all solvent in the solvation command
                    '''
                    if (sname, stype, scharge) not in CMD_solv_count.keys():
                        CMD_solv_count[(sname, stype, scharge)] = count
                    else:
                        CMD_solv_count[(sname, stype, scharge)] += count
                    
                    if (sname, stype, scharge) not in SYS_solv_count.keys():
                        SYS_solv_count[(sname, stype, scharge)] = count
                    else:
                        SYS_solv_count[(sname, stype, scharge)] += count

                CMD_headers = ["Name", "Totals", "Total %", "Molarity(box)", "Molarity(free)", "Molarity(solvent)", "Charge"]
                CMD_names, CMD_charges, CMD_counts = list(zip(*[(sname, scharge, scount) for (sname, stype, scharge), scount in CMD_solv_count.items()]))
                CMD_tot = sum(CMD_counts)
                if CMD_tot != 0:
                    CMD_percentages = [round(scount / CMD_tot * 100,           3) for scount in CMD_counts]
                else:
                    CMD_percentages = ["NaN" for scount in CMD_counts]
                CMD_box_molarity  = [round(scount / (N_A * box_volume),      3) for scount in CMD_counts]
                CMD_free_molarity = [round(scount / (N_A * box_free_volume), 3) for scount in CMD_counts]
                if solv_volume > 0:
                    CMD_solv_molarity = [round(scount / (N_A * solv_volume), 3) for scount in CMD_counts]
                else:
                    CMD_solv_molarity = ["NaN" for scount in CMD_counts]
                CMD_printer = [tuple(CMD_headers)] + list(zip(CMD_names, CMD_counts, CMD_percentages, CMD_box_molarity, CMD_free_molarity, CMD_solv_molarity, CMD_charges))
                CMD_max_lengths = [len(str(max(data, key = lambda d: len(str(d))))) for data in zip(*CMD_printer)]
                if self.extra_info and len(self.SOLVATIONS) > 1:
                    '''
                    Prints command-specific solvent information to the terminal
                    '''
                    self.print_term("", verbose=2)
                    self.print_term("Solvent data for the the specific solvation command", spaces=1, verbose=2)
                    for string in CMD_printer:
                        for_printer = []
                        for si, substring in enumerate(string):
                            for_printer.append('{0: <{L}}'.format(substring, L = CMD_max_lengths[si]))
                            if si+1 < len(string):
                                for_printer.append(":")
                        self.print_term(
                            *for_printer,
                            spaces=2,
                            verbose=2,
                        )

            if self.extra_info:
                '''
                Prints system-wide solvent information to the terminal
                '''
                self.print_term("", verbose=2)
                SYS_headers = ["Name", "Totals", "Total %", "Molarity(box)", "Molarity(free)", "Molarity(solvent)", "Charge"]
                SYS_names, SYS_charges, SYS_counts = list(zip(*[(sname, scharge, scount) for (sname, stype, scharge), scount in SYS_solv_count.items()]))
                SYS_tot = sum(SYS_counts)
                if SYS_tot > 0:
                    SYS_percentages = [round(count / SYS_tot * 100, 3) for count in SYS_counts]
                else:
                    SYS_percentages = ["NaN" for count in SYS_counts]
                ### Lipid volume
                lipid_beads_for_cell_checker, solvent_box_lipids_charge = self.get_lipid_volume(
                    -self.pbcx/2, self.pbcx/2, -self.pbcy/2, self.pbcy/2, -self.pbcz/2, self.pbcz/2
                )
                SYS_leafs_volume = bead_volume * len(lipid_beads_for_cell_checker)

                ### Protein volume
                prot_beads_for_cell_checker, solvent_box_proteins_charge = self.get_protein_volume(
                    -self.pbcx/2, self.pbcx/2, -self.pbcy/2, self.pbcy/2, -self.pbcz/2, self.pbcz/2
                )
                SYS_prots_volume = bead_volume * len(prot_beads_for_cell_checker)
                SYS_box_volume = (self.pbcx * self.pbcy * self.pbcz) * 10**-27
                SYS_free_volume = SYS_box_volume - leafs_volume - prots_volume
                
                SYS_box_molarity = [round(scount / (N_A * SYS_box_volume), 3) for scount in SYS_counts]
                SYS_free_molarity = [round(scount / (N_A * SYS_free_volume), 3) for scount in SYS_counts]
                if SYS_solv_volume > 0:
                    SYS_solv_molarity = [round(scount / (N_A * SYS_solv_volume), 3) for scount in SYS_counts]
                else:
                    SYS_solv_molarity = ["NaN" for scount in SYS_counts]
                SYS_printer = [tuple(SYS_headers)] + list(zip(SYS_names, SYS_counts, SYS_percentages, SYS_box_molarity, SYS_free_molarity, SYS_solv_molarity, SYS_charges))
                SYS_max_lengths = [len(str(max(data, key = lambda d: len(str(d))))) for data in zip(*SYS_printer)]
                self.print_term("Solvent data for whole system", verbose=2)
                for string in SYS_printer:
                    for_printer = []
                    for si, substring in enumerate(string):
                        for_printer.append('{0: <{L}}'.format(substring, L = SYS_max_lengths[si]))
                        if si+1 < len(string):
                            for_printer.append(":")
                    self.print_term(
                        *for_printer,
                        spaces=2,
                        verbose=2,
                    )
            
            solvation_toc = time.time()
            solvation_time = round(solvation_toc - solvation_tic, 3)
            string = " ".join(["", "SOLVATION COMPLETE", ""])
            self.print_term("{string:-^{string_length}}".format(string=string, string_length=self.terminalupdate_string_length), spaces=0, verbose=1)
            string = " ".join(["", "(Time spent:", str(solvation_time), "[s])", ""])
            self.print_term("{string:^{string_length}}".format(string=string, string_length=self.terminalupdate_string_length), "\n", spaces=0, verbose=1)
