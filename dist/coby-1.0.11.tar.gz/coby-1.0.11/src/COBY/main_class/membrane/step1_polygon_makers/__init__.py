'''
DOCSTRING TO BE WRITTEN
'''

from COBY.main_class.membrane.step1_polygon_makers.subleaflet_poly_maker import *
from COBY.main_class.membrane.step1_polygon_makers.holed_subleaflet_bbox_maker import *

class polygon_makers(
    subleaflet_poly_maker,
    holed_subleaflet_bbox_maker,
):
    def __init__(self):
        pass

