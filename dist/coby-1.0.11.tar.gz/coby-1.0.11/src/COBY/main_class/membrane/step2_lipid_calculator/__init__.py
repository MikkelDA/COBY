'''
DOCSTRING TO BE WRITTEN
'''

from COBY.main_class.membrane.step2_lipid_calculator.lipid_calculator import *
from COBY.main_class.membrane.step2_lipid_calculator.lipid_optimizer import *

class lipid_calculator(
    lipid_calculator,
    lipid_optimizer,
):
    def __init__(self):
        pass

