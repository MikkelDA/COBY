'''
DOCSTRING TO BE WRITTEN
'''

from COBY.main_class.special_preprocessors.stacked_membranes_preprocessor import *

class special_preprocessors(
    stacked_membranes_preprocessor,
):
    def __init__(self):
        pass

