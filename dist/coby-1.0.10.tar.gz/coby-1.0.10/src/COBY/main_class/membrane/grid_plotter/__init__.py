'''
DOCSTRING TO BE WRITTEN
'''

from COBY.main_class.membrane.grid_plotter.grid_plotter import *

class grid_plotter(
    grid_plotter,
):
    def __init__(self):
        pass

