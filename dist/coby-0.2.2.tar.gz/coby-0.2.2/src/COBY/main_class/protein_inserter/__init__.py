'''
DOCSTRING TO BE WRITTEN
'''

from COBY.main_class.protein_inserter.prot_placer import *

class protein_inserter(
    prot_placer,
):
    def __init__(self):
        pass

