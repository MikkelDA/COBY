'''
DOCSTRING TO BE WRITTEN
'''

from COBY.structure_classes.ATOM_class import ATOM
from COBY.structure_classes.RESIDUE_class import RESIDUE
from COBY.structure_classes.MOLECULE_class import MOLECULE
from COBY.structure_classes.LIPID_class import LIPID
from COBY.structure_classes.SOLVENT_class import SOLVENT
from COBY.structure_classes.PROTEIN_class import PROTEIN


