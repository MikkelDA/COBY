'''
DOCSTRING TO BE WRITTEN
'''

from COBY.main_class.solvater.get_solute_volume import *
from COBY.main_class.solvater.get_lipid_volume import *
from COBY.main_class.solvater.get_protein_volume import *
from COBY.main_class.solvater.solvater import *

class solvater(
    get_solute_volume,
    get_lipid_volume,
    get_protein_volume,
    solvater,
):
    def __init__(self):
        pass

